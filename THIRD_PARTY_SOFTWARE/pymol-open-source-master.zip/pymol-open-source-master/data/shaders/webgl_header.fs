#ifndef ONE_DRAW_BUFFER
#ifdef PURE_OPENGL_ES_2
#extension GL_EXT_draw_buffers : require
#endif
#endif

#ifdef PYMOL_WEBGL_IOS
precision highp float;
#endif
