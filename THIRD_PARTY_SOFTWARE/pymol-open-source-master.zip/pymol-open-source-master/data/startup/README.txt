Plugin directory outside pmg_tk.
