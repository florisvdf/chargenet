#ifndef _H_chiral
#define _H_chiral

void ChiralInit(void);
int ChiralHandedness(int *a);

#endif
