/*
 * MacroModel atom typing
 *
 * (c) Schrodinger, Inc.
 */

struct AtomInfoType;

int getMacroModelAtomType(const AtomInfoType * ai);
