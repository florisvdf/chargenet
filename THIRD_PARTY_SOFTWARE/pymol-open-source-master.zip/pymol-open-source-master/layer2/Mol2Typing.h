/*
 * Mol2 atom typing
 *
 * (c) Schrodinger, Inc.
 */

struct ObjectMolecule;

const char * getMOL2Type(ObjectMolecule * obj, int atm);
