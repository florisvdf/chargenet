#pragma once

namespace pymol
{
enum class RenderContext
{
  Camera = 0,
  UnitWindow = 1
};
} // namespace pymol

