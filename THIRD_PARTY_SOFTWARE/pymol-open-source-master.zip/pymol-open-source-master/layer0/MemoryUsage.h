/*
 * Memory usage info
 */

#pragma once

namespace pymol
{

size_t memory_usage();
size_t memory_available();

} // namespace pymol
